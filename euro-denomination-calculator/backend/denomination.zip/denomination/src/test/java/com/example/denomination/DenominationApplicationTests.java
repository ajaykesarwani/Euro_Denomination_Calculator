package com.example.denomination;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DenominationApplicationTests {

	@Test
	void contextLoads() {
	}

}
